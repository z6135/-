var e = require("../../utils/util.js"), time = require('../../utils/util.js');
var app = getApp();

const db=wx.cloud.database();
Page({

  data: {
    
    userInfo: {},
    hasUserInfo: false,
    ShowView: true,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    score: 5,
    images: [],
    fileIds: [],
  },

  //事件处理函数 查看日志

  bindViewTap: function() {

    wx.navigateTo({

      url: '../index/index'

    })

  },

  onShow:function(){

    this.login();

  },

  showButton:function(){
    var that = this;
    that.setData({
      showView: (!that.data.showView)
    })
  },

  submit: function(){
    wx.showLoading({
      title: '评价中·············',
    })
  console.log(this.data.content);
    //上传图片到云存储
    let promiseArr = [];
    for (let i = 0; i < this.data.images.length; i++) {
      promiseArr.push(new Promise((reslove, reject)=>{
      // 将图片上传至云存储空间
      let item = this.data.images[i];
      let suffix = /\.\w+$/.exec(item)[0] ;   //正则表达式，返回文件扩展名
      wx.cloud.uploadFile({
        // 指定上传到的云路径
        cloudPath: new Date().getTime() + suffix,
        // 指定要上传的文件的小程序临时文件路径
        filePath: item,
        // 成功回调
        success: res => {
          console.log(res.fileID)
          this.setData({
            fileIds: this.data.fileIds.concat(res.fileID)
          });
          reslove();
        },
      })
      }));
      
    }
  
    Promise.all(promiseArr).then(res =>{
      //插入数据
      db.collection('comment').add({
        data: {
          content: this.data.content,
          score: this.data.score,
          movieid: this.data.movieId,
          fileIds: this.data.fileIds
        }
      }).then(res=>{
        wx.hideLoading();
        wx.showToast({
          title: '评价成功',
        }).catch(err=>{
          wx.hideLoading();
          wx.showToast({
            title: '评论失败',
          })
        })
      })
    });
  },
  
  onContentChange: function(event){
  this.setData({
    content: event.detail
  });
  },
  
  onScoreChange: function(event){
  this.setData({
    score: event.detail
  });
  },
  
  
  
  uploadImg: function(){
    wx.chooseImage({
      count: 9, //选择多少图片
      sizeType: ['original', 'compressed'], //图片是否选择压缩 original-原尺寸  compressed-被压缩的
      sourceType: ['album', 'camera'],  //资源的来源
      success: res => {
        // tempFilePath可以作为img标签的src属性显示图片
        const tempFilePaths = res.tempFilePaths
        this.setData({
          images: this.data.images.concat(tempFilePaths)
        });
      }
    })
  },

  onLoad: function () {

    if (app.globalData.userInfo) {

      this.setData({

        userInfo: app.globalData.userInfo,

        hasUserInfo: true,

        number: true

      })

    } else if (this.data.canIUse){

      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回

      // 所以此处加入 callback 以防止这种情况

      app.userInfoReadyCallback = res => {

        this.setData({

          userInfo: res.userInfo,

          hasUserInfo: true

        })

      }

    } else {

      // 在没有 open-type=getUserInfo 版本的兼容处理

      wx.getUserInfo({

        success: res => {

          app.globalData.userInfo = res.userInfo

          this.setData({

            userInfo: res.userInfo,

            hasUserInfo: true

          })

        }

      })

    }

  },

  getUserInfo: function(e) {

    if(e.detail.userInfo){

      app.globalData.userInfo = e.detail.userInfo

      this.setData({

        userInfo: e.detail.userInfo,

        hasUserInfo: true

      })

    }else{

      this.openSetting();

    }

  },

  login: function () {

    var that = this;

    wx.login({

      success: function (res) {

        var code = res.code;

        console.log(code);

        wx.getUserInfo({

          success: function (res) {

            app.globalData.userInfo = res.userInfo

            that.setData({

              userInfo: res.userInfo,

              hasUserInfo: true

            })

          }

        })

      }

    })

  },

  //跳转设置页面授权

  openSetting: function () {

    var that = this

    if (wx.openSetting) {

      wx.openSetting({

        success: function (res) {

          console.log(9);

          //尝试再次登录

          that.login()

        }

      })

    } else {

      wx.showModal({

        title: '授权提示',

        content: '小程序需要您的微信授权才能使用哦~ 错过授权页面的处理方法：删除小程序->重新搜索进入->点击授权按钮'

      })

    }

  }

})